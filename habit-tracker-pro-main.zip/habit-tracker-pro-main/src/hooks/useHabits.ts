import { useState, useEffect, useCallback } from 'react';
import { Habit, HabitStore } from '@/types/habit';
import { format, differenceInDays, parseISO, startOfMonth, isSameMonth } from 'date-fns';

const STORAGE_KEY = 'habitforge-data';

const getInitialStore = (): HabitStore => {
  const today = new Date();
  return {
    habits: [],
    currentMonth: format(today, 'yyyy-MM'),
    monthStartDate: format(today, 'yyyy-MM-dd'),
  };
};

const loadStore = (): HabitStore => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (e) {
    console.error('Failed to load habits:', e);
  }
  return getInitialStore();
};

const saveStore = (store: HabitStore) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
};

export const useHabits = () => {
  const [store, setStore] = useState<HabitStore>(loadStore);
  const today = format(new Date(), 'yyyy-MM-dd');

  useEffect(() => {
    saveStore(store);
  }, [store]);

  const getConsecutiveDays = useCallback((habit: Habit): number => {
    if (habit.completedDays.length === 0) return 0;
    
    const sortedDays = [...habit.completedDays].sort().reverse();
    let streak = 0;
    let currentDate = new Date();
    
    // Check if today or yesterday was completed to start streak
    const todayStr = format(currentDate, 'yyyy-MM-dd');
    const yesterdayStr = format(new Date(currentDate.setDate(currentDate.getDate() - 1)), 'yyyy-MM-dd');
    
    currentDate = new Date(); // Reset
    
    if (!sortedDays.includes(todayStr) && !sortedDays.includes(yesterdayStr)) {
      return 0;
    }
    
    // Count consecutive days backwards from most recent completed day
    for (let i = 0; i < sortedDays.length; i++) {
      const dayDate = parseISO(sortedDays[i]);
      const expectedDate = new Date();
      expectedDate.setDate(expectedDate.getDate() - streak);
      
      if (format(dayDate, 'yyyy-MM-dd') === format(expectedDate, 'yyyy-MM-dd')) {
        streak++;
      } else if (streak === 0) {
        // Check if it's yesterday
        expectedDate.setDate(expectedDate.getDate() - 1);
        if (format(dayDate, 'yyyy-MM-dd') === format(expectedDate, 'yyyy-MM-dd')) {
          streak++;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    
    return streak;
  }, []);

  const canAddHabit = useCallback((): boolean => {
    const activeHabits = store.habits.filter(h => !h.isArchived);
    
    // Check max 10 habits
    if (activeHabits.length >= 10) return false;
    
    // If no habits exist, allow adding first one
    if (activeHabits.length === 0) return true;
    
    // Check if any habit has 3+ consecutive days
    return activeHabits.some(h => getConsecutiveDays(h) >= 3);
  }, [store.habits, getConsecutiveDays]);

  const addHabit = useCallback((name: string) => {
    if (!canAddHabit()) return false;
    
    const newHabit: Habit = {
      id: crypto.randomUUID(),
      name,
      createdAt: today,
      completedDays: [],
    };
    
    setStore(prev => ({
      ...prev,
      habits: [...prev.habits, newHabit],
    }));
    
    return true;
  }, [canAddHabit, today]);

  const toggleDay = useCallback((habitId: string, date: string) => {
    // Prevent checking future days
    if (date > today) return;
    
    setStore(prev => ({
      ...prev,
      habits: prev.habits.map(habit => {
        if (habit.id !== habitId) return habit;
        
        const isCompleted = habit.completedDays.includes(date);
        let newCompletedDays: string[];
        
        if (isCompleted) {
          newCompletedDays = habit.completedDays.filter(d => d !== date);
        } else {
          newCompletedDays = [...habit.completedDays, date];
        }
        
        // Check if habit just hit 21 consecutive days
        const updatedHabit = { ...habit, completedDays: newCompletedDays };
        const streak = getConsecutiveDays(updatedHabit);
        
        if (streak >= 21 && !habit.completedAt21) {
          updatedHabit.completedAt21 = today;
          updatedHabit.lastCheckIn = today;
        }
        
        return updatedHabit;
      }),
    }));
  }, [today, getConsecutiveDays]);

  const needsCheckIn = useCallback((habit: Habit): boolean => {
    if (!habit.completedAt21 || !habit.lastCheckIn) return false;
    
    const daysSinceCheckIn = differenceInDays(new Date(), parseISO(habit.lastCheckIn));
    return daysSinceCheckIn >= 3;
  }, []);

  const handleCheckInResponse = useCallback((habitId: string, stillFollowing: boolean) => {
    setStore(prev => ({
      ...prev,
      habits: prev.habits.map(habit => {
        if (habit.id !== habitId) return habit;
        
        if (stillFollowing) {
          return { ...habit, lastCheckIn: today };
        } else {
          // Reset habit - archive old one and create new
          return { ...habit, isArchived: true };
        }
      }),
    }));
    
    if (!stillFollowing) {
      // Return true to indicate a new habit can be added
      return true;
    }
    return false;
  }, [today]);

  const deleteHabit = useCallback((habitId: string) => {
    setStore(prev => ({
      ...prev,
      habits: prev.habits.filter(h => h.id !== habitId),
    }));
  }, []);

  const getDaysSinceStart = useCallback((): number => {
    return differenceInDays(new Date(), parseISO(store.monthStartDate)) + 1;
  }, [store.monthStartDate]);

  const isNewMonth = useCallback((): boolean => {
    const currentMonth = format(new Date(), 'yyyy-MM');
    return currentMonth !== store.currentMonth && getDaysSinceStart() >= 30;
  }, [store.currentMonth, getDaysSinceStart]);

  const startNewMonth = useCallback(() => {
    const today = new Date();
    setStore({
      habits: [],
      currentMonth: format(today, 'yyyy-MM'),
      monthStartDate: format(today, 'yyyy-MM-dd'),
    });
  }, []);

  const getActiveHabits = useCallback(() => {
    return store.habits.filter(h => !h.isArchived);
  }, [store.habits]);

  return {
    habits: getActiveHabits(),
    allHabits: store.habits,
    monthStartDate: store.monthStartDate,
    addHabit,
    toggleDay,
    deleteHabit,
    canAddHabit,
    getConsecutiveDays,
    needsCheckIn,
    handleCheckInResponse,
    getDaysSinceStart,
    isNewMonth,
    startNewMonth,
    today,
  };
};
