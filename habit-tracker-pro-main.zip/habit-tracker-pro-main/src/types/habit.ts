export interface Habit {
  id: string;
  name: string;
  createdAt: string;
  completedDays: string[]; // Array of date strings (YYYY-MM-DD)
  completedAt21?: string; // Date when habit hit 21 days
  lastCheckIn?: string; // Last check-in date after 21 days
  isArchived?: boolean;
}

export interface HabitStore {
  habits: Habit[];
  currentMonth: string; // YYYY-MM format
  monthStartDate: string; // The actual start date of tracking
}
