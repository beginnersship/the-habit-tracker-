import { useState, useEffect } from 'react';
import { useHabits } from '@/hooks/useHabits';
import { HabitTable } from '@/components/HabitTable';
import { AddHabitDialog } from '@/components/AddHabitDialog';
import { CheckInDialog } from '@/components/CheckInDialog';
import { ProgressStats } from '@/components/ProgressStats';
import { MonthlyReportDialog } from '@/components/MonthlyReportDialog';
import { WelcomeIntro } from '@/components/WelcomeIntro';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { Habit } from '@/types/habit';

const Index = () => {
  const {
    habits,
    allHabits,
    monthStartDate,
    addHabit,
    toggleDay,
    deleteHabit,
    canAddHabit,
    getConsecutiveDays,
    needsCheckIn,
    handleCheckInResponse,
    getDaysSinceStart,
    isNewMonth,
    startNewMonth,
    today,
  } = useHabits();

  // Show intro only once per session
  const [showIntro, setShowIntro] = useState(() => {
    const hasSeenIntro = sessionStorage.getItem('habitforge-intro-seen');
    return !hasSeenIntro;
  });

  const handleIntroComplete = () => {
    sessionStorage.setItem('habitforge-intro-seen', 'true');
    setShowIntro(false);
  };
  const [checkInHabit, setCheckInHabit] = useState<Habit | null>(null);

  // Check for habits needing check-in on load
  useEffect(() => {
    if (!showIntro) {
      const habitNeedingCheckIn = habits.find(needsCheckIn);
      if (habitNeedingCheckIn) {
        setCheckInHabit(habitNeedingCheckIn);
      }
    }
  }, [habits, needsCheckIn, showIntro]);

  const handleCheckInResponseWrapper = (habitId: string, stillFollowing: boolean) => {
    const shouldAddNew = handleCheckInResponse(habitId, stillFollowing);
    setCheckInHabit(null);
    
    if (stillFollowing) {
      toast.success('Wonderful! Keep up the amazing work! 🌟');
    } else {
      toast.info('No worries! A fresh start is waiting for you.');
    }
  };

  const daysSinceStart = getDaysSinceStart();
  const canGenerateReport = daysSinceStart >= 30;

  if (showIntro) {
    return <WelcomeIntro onComplete={handleIntroComplete} />;
  }

  return (
    <div className="min-h-screen bg-background animate-fade-in">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-20">
        <div className="container max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">
                <span className="text-primary">Habit</span>Forge
              </h1>
              <p className="text-sm text-muted-foreground">
                Build discipline, one day at a time
              </p>
            </div>
            <div className="flex items-center gap-3">
              <MonthlyReportDialog
                habits={habits}
                allHabits={allHabits}
                daysSinceStart={daysSinceStart}
                canGenerate={canGenerateReport}
                onStartNewMonth={startNewMonth}
                getConsecutiveDays={getConsecutiveDays}
              />
            </div>
          </div>
        </div>
      </header>

      <main className="container max-w-7xl mx-auto px-4 py-8 space-y-8">
        {/* Progress Stats */}
        <ProgressStats
          habits={habits}
          daysSinceStart={daysSinceStart}
          getConsecutiveDays={getConsecutiveDays}
        />

        {/* Habit Tracker Card */}
        <Card className="border-border/50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
            <CardTitle className="text-lg font-semibold">
              Your Habits
              <span className="ml-2 text-sm font-normal text-muted-foreground">
                ({habits.length}/10)
              </span>
            </CardTitle>
            <AddHabitDialog
              canAdd={canAddHabit()}
              onAdd={addHabit}
              habitCount={habits.length}
            />
          </CardHeader>
          <CardContent className="p-0">
            <HabitTable
              habits={habits}
              today={today}
              onToggleDay={toggleDay}
              onDeleteHabit={deleteHabit}
              getConsecutiveDays={getConsecutiveDays}
            />
          </CardContent>
        </Card>

        {/* Tips Section */}
        <div className="grid md:grid-cols-3 gap-4">
          <Card className="border-border/50 bg-primary/5">
            <CardContent className="p-4">
              <div className="text-2xl mb-2">🔥</div>
              <h3 className="font-semibold mb-1">Build Streaks</h3>
              <p className="text-sm text-muted-foreground">
                Complete a habit for 3 consecutive days to unlock new habit slots.
              </p>
            </CardContent>
          </Card>
          <Card className="border-border/50 bg-chart-2/5">
            <CardContent className="p-4">
              <div className="text-2xl mb-2">🏆</div>
              <h3 className="font-semibold mb-1">21-Day Rule</h3>
              <p className="text-sm text-muted-foreground">
                Reach 21 consecutive days to master a habit and cement it into your routine.
              </p>
            </CardContent>
          </Card>
          <Card className="border-border/50 bg-chart-1/5">
            <CardContent className="p-4">
              <div className="text-2xl mb-2">📊</div>
              <h3 className="font-semibold mb-1">Monthly Reports</h3>
              <p className="text-sm text-muted-foreground">
                After 30 days, get insights on your progress and start fresh.
              </p>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Check-in Dialog */}
      <CheckInDialog
        habit={checkInHabit}
        onResponse={handleCheckInResponseWrapper}
      />
    </div>
  );
};

export default Index;
