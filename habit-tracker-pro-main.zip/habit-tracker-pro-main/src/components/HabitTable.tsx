import { Habit } from '@/types/habit';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isToday, isFuture } from 'date-fns';
import { Flame, Trash2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';

interface HabitTableProps {
  habits: Habit[];
  today: string;
  onToggleDay: (habitId: string, date: string) => void;
  onDeleteHabit: (habitId: string) => void;
  getConsecutiveDays: (habit: Habit) => number;
}

export const HabitTable = ({
  habits,
  today,
  onToggleDay,
  onDeleteHabit,
  getConsecutiveDays,
}: HabitTableProps) => {
  const currentDate = new Date();
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

  if (habits.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
        <div className="text-6xl mb-4">🌱</div>
        <p className="text-lg font-medium">No habits yet</p>
        <p className="text-sm">Add your first habit to start building discipline!</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr>
            <th className="sticky left-0 bg-card z-10 p-3 text-left font-semibold min-w-[150px] border-b border-border">
              Habit
            </th>
            {days.map((day) => {
              const dayStr = format(day, 'yyyy-MM-dd');
              const isCurrentDay = isToday(day);
              const isFutureDay = isFuture(day);
              
              return (
                <th
                  key={dayStr}
                  className={cn(
                    "p-1 text-center font-medium text-xs min-w-[32px] border-b border-border",
                    isCurrentDay && "bg-primary/10",
                    isFutureDay && "opacity-40"
                  )}
                >
                  <div className="flex flex-col items-center">
                    <span className="text-[10px] text-muted-foreground">
                      {format(day, 'EEE')}
                    </span>
                    <span className={cn(
                      "w-6 h-6 flex items-center justify-center rounded-full text-xs",
                      isCurrentDay && "bg-primary text-primary-foreground font-bold"
                    )}>
                      {format(day, 'd')}
                    </span>
                  </div>
                </th>
              );
            })}
            <th className="p-2 min-w-[40px] border-b border-border">
              <span className="sr-only">Actions</span>
            </th>
          </tr>
        </thead>
        <tbody>
          {habits.map((habit) => {
            const streak = getConsecutiveDays(habit);
            const hasReached21 = habit.completedAt21;
            
            return (
              <tr key={habit.id} className="group hover:bg-accent/30 transition-colors">
                <td className="sticky left-0 bg-card group-hover:bg-accent/30 z-10 p-3 border-b border-border transition-colors">
                  <div className="flex items-center gap-2">
                    <span className="font-medium truncate max-w-[110px]">{habit.name}</span>
                    {streak >= 3 && (
                      <Tooltip>
                        <TooltipTrigger>
                          <div className={cn(
                            "flex items-center gap-1 px-1.5 py-0.5 rounded-full text-xs font-semibold",
                            hasReached21 
                              ? "bg-primary/20 text-primary" 
                              : "bg-destructive/20 text-destructive"
                          )}>
                            <Flame className="w-3 h-3" />
                            {streak}
                          </div>
                        </TooltipTrigger>
                        <TooltipContent>
                          {hasReached21 
                            ? "Habit mastered! Keep it up!" 
                            : `${21 - streak} days to master this habit`}
                        </TooltipContent>
                      </Tooltip>
                    )}
                  </div>
                </td>
                {days.map((day) => {
                  const dayStr = format(day, 'yyyy-MM-dd');
                  const isCompleted = habit.completedDays.includes(dayStr);
                  const isFutureDay = isFuture(day);
                  const isCurrentDay = isToday(day);
                  
                  return (
                    <td
                      key={dayStr}
                      className={cn(
                        "p-1 text-center border-b border-border",
                        isCurrentDay && "bg-primary/5"
                      )}
                    >
                      <div className="flex items-center justify-center">
                        <Checkbox
                          checked={isCompleted}
                          onCheckedChange={() => !isFutureDay && onToggleDay(habit.id, dayStr)}
                          disabled={isFutureDay}
                          className={cn(
                            "h-5 w-5",
                            isFutureDay && "opacity-30 cursor-not-allowed"
                          )}
                        />
                      </div>
                    </td>
                  );
                })}
                <td className="p-2 border-b border-border">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="opacity-0 group-hover:opacity-100 transition-opacity h-7 w-7 text-muted-foreground hover:text-destructive"
                    onClick={() => onDeleteHabit(habit.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
