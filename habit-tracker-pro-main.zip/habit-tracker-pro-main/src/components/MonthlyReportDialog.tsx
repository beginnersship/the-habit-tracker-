import { Habit } from '@/types/habit';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { FileText, Trophy, Flame, Target, ArrowRight } from 'lucide-react';
import { format, parseISO } from 'date-fns';

interface MonthlyReportDialogProps {
  habits: Habit[];
  allHabits: Habit[];
  daysSinceStart: number;
  canGenerate: boolean;
  onStartNewMonth: () => void;
  getConsecutiveDays: (habit: Habit) => number;
}

export const MonthlyReportDialog = ({
  habits,
  allHabits,
  daysSinceStart,
  canGenerate,
  onStartNewMonth,
  getConsecutiveDays,
}: MonthlyReportDialogProps) => {
  const totalCompletions = allHabits.reduce((sum, h) => sum + h.completedDays.length, 0);
  const masteredHabits = allHabits.filter(h => h.completedAt21);
  const bestStreak = Math.max(0, ...allHabits.map(getConsecutiveDays));
  const possibleCompletions = allHabits.reduce((sum, h) => Math.min(daysSinceStart, 30), 0);
  const completionRate = possibleCompletions > 0 
    ? Math.round((totalCompletions / possibleCompletions) * 100) 
    : 0;

  const getInsight = () => {
    if (masteredHabits.length >= 3) {
      return "Outstanding discipline! You've mastered multiple habits this month. You're building a strong foundation for long-term success.";
    } else if (masteredHabits.length >= 1) {
      return "Great progress! Mastering even one habit shows real commitment. Keep building on this momentum.";
    } else if (completionRate >= 70) {
      return "You're showing strong consistency! A few more days and you'll start mastering habits.";
    } else if (completionRate >= 40) {
      return "You're making progress! Try focusing on fewer habits to build stronger streaks.";
    } else {
      return "Every journey starts with a single step. Focus on one habit and build from there.";
    }
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button 
          variant={canGenerate ? "default" : "outline"}
          className="gap-2"
          disabled={!canGenerate && daysSinceStart < 30}
        >
          <FileText className="w-4 h-4" />
          {canGenerate ? 'Generate Report' : `Report in ${30 - daysSinceStart} days`}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-primary" />
            Monthly Progress Report
          </DialogTitle>
          <DialogDescription>
            Your habit-building journey this month
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-lg bg-accent/50">
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                <Target className="w-4 h-4" />
                Completion Rate
              </div>
              <p className="text-2xl font-bold">{completionRate}%</p>
            </div>
            <div className="p-4 rounded-lg bg-accent/50">
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                <Flame className="w-4 h-4" />
                Best Streak
              </div>
              <p className="text-2xl font-bold">{bestStreak} days</p>
            </div>
          </div>

          {/* Mastered Habits */}
          {masteredHabits.length > 0 && (
            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Trophy className="w-4 h-4 text-primary" />
                Mastered Habits ({masteredHabits.length})
              </h4>
              <ul className="space-y-1">
                {masteredHabits.map(h => (
                  <li key={h.id} className="text-sm text-muted-foreground flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                    {h.name}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* AI Insight */}
          <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
            <h4 className="font-semibold mb-2">💡 Insight</h4>
            <p className="text-sm text-muted-foreground">{getInsight()}</p>
          </div>
        </div>

        <DialogFooter>
          <Button onClick={onStartNewMonth} className="gap-2">
            Start New Month
            <ArrowRight className="w-4 h-4" />
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
