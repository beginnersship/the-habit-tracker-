import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { TrendingUp, Flame, Target, Trophy } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface WelcomeIntroProps {
  onComplete: () => void;
}

export const WelcomeIntro = ({ onComplete }: WelcomeIntroProps) => {
  const [stage, setStage] = useState(0);
  const [isExiting, setIsExiting] = useState(false);

  // Play a subtle chime sound
  useEffect(() => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      const playChime = (frequency: number, delay: number, duration: number = 0.3) => {
        setTimeout(() => {
          const oscillator = audioContext.createOscillator();
          const gainNode = audioContext.createGain();
          
          oscillator.connect(gainNode);
          gainNode.connect(audioContext.destination);
          
          oscillator.frequency.value = frequency;
          oscillator.type = 'sine';
          
          gainNode.gain.setValueAtTime(0.15, audioContext.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + duration);
          
          oscillator.start(audioContext.currentTime);
          oscillator.stop(audioContext.currentTime + duration);
        }, delay);
      };

      playChime(523.25, 300, 0.2);
      playChime(659.25, 500, 0.2);
      playChime(783.99, 700, 0.4);
    } catch (e) {
      console.log('Audio not supported');
    }
  }, []);

  useEffect(() => {
    const timers = [
      setTimeout(() => setStage(1), 100),
      setTimeout(() => setStage(2), 400),
      setTimeout(() => setStage(3), 800),
      setTimeout(() => setStage(4), 1200),
      setTimeout(() => setStage(5), 1600),
      setTimeout(() => handleComplete(), 4000),
    ];

    return () => timers.forEach(clearTimeout);
  }, []);

  const handleComplete = () => {
    setIsExiting(true);
    setTimeout(onComplete, 500);
  };

  return (
    <div 
      className={cn(
        "fixed inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 transition-all duration-500",
        isExiting && "opacity-0 scale-105"
      )}
    >
      {/* Animated background particles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(30)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 rounded-full bg-primary/40 animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 2}s`,
              animationDuration: `${2 + Math.random() * 2}s`,
            }}
          />
        ))}
      </div>

      {/* Skip button */}
      <Button
        variant="ghost"
        size="sm"
        onClick={handleComplete}
        className="absolute top-4 right-4 text-white/60 hover:text-white hover:bg-white/10"
      >
        Skip
      </Button>

      {/* Main content */}
      <div className="relative z-10 flex flex-col items-center gap-6 px-4">
        {/* Animated Graph Logo */}
        <div 
          className={cn(
            "relative transition-all duration-700 ease-out",
            stage >= 1 ? "opacity-100 scale-100" : "opacity-0 scale-50"
          )}
        >
          <div className="relative w-36 h-36 flex items-center justify-center">
            {/* Glowing background */}
            <div className="absolute inset-0 bg-primary/30 rounded-full blur-2xl animate-pulse" />
            
            {/* Graph bars animation */}
            <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-lg">
              {/* Background circle */}
              <circle 
                cx="50" cy="50" r="45" 
                fill="rgba(255,255,255,0.05)"
                stroke="rgba(255,255,255,0.2)" 
                strokeWidth="2" 
              />
              
              {/* Animated progress circle */}
              <circle 
                cx="50" cy="50" r="45" 
                fill="none" 
                stroke="hsl(var(--primary))"
                strokeWidth="3" 
                strokeLinecap="round"
                strokeDasharray="283"
                strokeDashoffset={stage >= 2 ? "70" : "283"}
                style={{ 
                  transition: 'stroke-dashoffset 1s ease-out',
                  transform: 'rotate(-90deg)',
                  transformOrigin: 'center'
                }}
              />
              
              {/* Bar chart inside */}
              <g transform="translate(25, 28)">
                {[
                  { height: 28, delay: 0, color: 'hsl(var(--primary))' },
                  { height: 38, delay: 100, color: 'hsl(var(--chart-2))' },
                  { height: 22, delay: 200, color: 'hsl(var(--primary))' },
                  { height: 44, delay: 300, color: 'hsl(var(--chart-2))' },
                ].map((bar, i) => (
                  <rect
                    key={i}
                    x={i * 13}
                    y={stage >= 2 ? 44 - bar.height : 44}
                    width="10"
                    rx="2"
                    height={stage >= 2 ? bar.height : 0}
                    fill={bar.color}
                    style={{
                      transition: `all 0.6s ease-out ${bar.delay}ms`
                    }}
                  />
                ))}
              </g>
              
              {/* Trend line */}
              <path
                d="M 28 62 Q 42 48, 50 52 T 72 32"
                fill="none"
                stroke="hsl(var(--chart-1))"
                strokeWidth="3"
                strokeLinecap="round"
                strokeDasharray="60"
                strokeDashoffset={stage >= 3 ? "0" : "60"}
                style={{ transition: 'stroke-dashoffset 0.8s ease-out 0.4s' }}
              />
            </svg>
            
            {/* Trending icon */}
            <TrendingUp 
              className={cn(
                "absolute -top-1 -right-1 w-8 h-8 text-emerald-400 transition-all duration-500 drop-shadow-lg",
                stage >= 3 ? "opacity-100 scale-100" : "opacity-0 scale-0"
              )}
            />
          </div>
        </div>

        {/* Title */}
        <h1 
          className={cn(
            "text-5xl md:text-6xl font-bold transition-all duration-700",
            stage >= 2 ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          )}
        >
          <span className="text-primary">Habit</span>
          <span className="text-white">Forge</span>
        </h1>

        {/* Motivational tagline */}
        <p 
          className={cn(
            "text-lg md:text-xl text-slate-300 text-center max-w-md transition-all duration-700",
            stage >= 3 ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          )}
        >
          Your journey to greatness starts with a single habit
        </p>

        {/* Feature icons */}
        <div 
          className={cn(
            "flex items-center gap-8 mt-4 transition-all duration-700",
            stage >= 4 ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          )}
        >
          <div className="flex flex-col items-center gap-2">
            <div className="w-14 h-14 rounded-full bg-red-500/20 flex items-center justify-center border border-red-500/30">
              <Flame className="w-7 h-7 text-red-400" />
            </div>
            <span className="text-xs text-slate-400">Build Streaks</span>
          </div>
          <div className="flex flex-col items-center gap-2">
            <div className="w-14 h-14 rounded-full bg-primary/20 flex items-center justify-center border border-primary/30">
              <Target className="w-7 h-7 text-primary" />
            </div>
            <span className="text-xs text-slate-400">21-Day Goals</span>
          </div>
          <div className="flex flex-col items-center gap-2">
            <div className="w-14 h-14 rounded-full bg-amber-500/20 flex items-center justify-center border border-amber-500/30">
              <Trophy className="w-7 h-7 text-amber-400" />
            </div>
            <span className="text-xs text-slate-400">Master Habits</span>
          </div>
        </div>

        {/* Motivational quote */}
        <p 
          className={cn(
            "text-sm italic text-slate-400 text-center mt-6 max-w-sm transition-all duration-700",
            stage >= 5 ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
          )}
        >
          "We are what we repeatedly do. Excellence, then, is not an act, but a habit."
          <span className="block mt-1 not-italic font-medium text-slate-300">— Aristotle</span>
        </p>

        {/* Loading dots */}
        <div 
          className={cn(
            "flex items-center gap-2 mt-4 transition-all duration-500",
            stage >= 4 ? "opacity-100" : "opacity-0"
          )}
        >
          <div className="flex gap-1.5">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="w-2.5 h-2.5 rounded-full bg-primary animate-bounce"
                style={{ animationDelay: `${i * 0.15}s` }}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
