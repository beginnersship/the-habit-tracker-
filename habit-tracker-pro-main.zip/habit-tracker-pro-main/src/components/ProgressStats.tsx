import { Habit } from '@/types/habit';
import { Card, CardContent } from '@/components/ui/card';
import { Flame, Target, Trophy, Calendar } from 'lucide-react';

interface ProgressStatsProps {
  habits: Habit[];
  daysSinceStart: number;
  getConsecutiveDays: (habit: Habit) => number;
}

export const ProgressStats = ({ habits, daysSinceStart, getConsecutiveDays }: ProgressStatsProps) => {
  const totalCompletions = habits.reduce((sum, h) => sum + h.completedDays.length, 0);
  const masteredHabits = habits.filter(h => h.completedAt21).length;
  const bestStreak = Math.max(0, ...habits.map(getConsecutiveDays));
  const possibleCompletions = habits.reduce((sum, h) => {
    const habitDays = Math.min(daysSinceStart, 30);
    return sum + habitDays;
  }, 0);
  const completionRate = possibleCompletions > 0 
    ? Math.round((totalCompletions / possibleCompletions) * 100) 
    : 0;

  const stats = [
    {
      label: 'Day',
      value: Math.min(daysSinceStart, 30),
      suffix: '/30',
      icon: Calendar,
      color: 'text-chart-1',
      bgColor: 'bg-chart-1/10',
    },
    {
      label: 'Completion Rate',
      value: completionRate,
      suffix: '%',
      icon: Target,
      color: 'text-chart-2',
      bgColor: 'bg-chart-2/10',
    },
    {
      label: 'Best Streak',
      value: bestStreak,
      suffix: ' days',
      icon: Flame,
      color: 'text-destructive',
      bgColor: 'bg-destructive/10',
    },
    {
      label: 'Mastered',
      value: masteredHabits,
      suffix: ` habit${masteredHabits !== 1 ? 's' : ''}`,
      icon: Trophy,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
    },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat) => (
        <Card key={stat.label} className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                <stat.icon className={`w-5 h-5 ${stat.color}`} />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  {stat.value}
                  <span className="text-sm font-normal text-muted-foreground">
                    {stat.suffix}
                  </span>
                </p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};
