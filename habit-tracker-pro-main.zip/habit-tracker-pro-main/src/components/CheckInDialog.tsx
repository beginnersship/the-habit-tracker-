import { Habit } from '@/types/habit';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Sparkles, RefreshCw } from 'lucide-react';

interface CheckInDialogProps {
  habit: Habit | null;
  onResponse: (habitId: string, stillFollowing: boolean) => void;
}

export const CheckInDialog = ({ habit, onResponse }: CheckInDialogProps) => {
  if (!habit) return null;

  return (
    <AlertDialog open={!!habit}>
      <AlertDialogContent className="max-w-md">
        <AlertDialogHeader>
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
              <Sparkles className="w-8 h-8 text-primary" />
            </div>
          </div>
          <AlertDialogTitle className="text-center">
            Check-in: {habit.name}
          </AlertDialogTitle>
          <AlertDialogDescription className="text-center text-base">
            You mastered this habit! 🎉
            <br />
            <span className="font-medium mt-2 block">
              Are you still following this habit continuously?
            </span>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="flex-col sm:flex-row gap-2 mt-4">
          <AlertDialogCancel
            onClick={() => onResponse(habit.id, false)}
            className="flex items-center gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            No, I need to restart
          </AlertDialogCancel>
          <AlertDialogAction
            onClick={() => onResponse(habit.id, true)}
            className="flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            Yes, still going!
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};
