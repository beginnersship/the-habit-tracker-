import { useState } from 'react';
import { Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

interface AddHabitDialogProps {
  canAdd: boolean;
  onAdd: (name: string) => boolean;
  habitCount: number;
}

export const AddHabitDialog = ({ canAdd, onAdd, habitCount }: AddHabitDialogProps) => {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) {
      toast.error('Please enter a habit name');
      return;
    }
    
    const success = onAdd(name.trim());
    
    if (success) {
      toast.success('Habit added! Start building your streak.');
      setName('');
      setOpen(false);
    } else {
      toast.error('Could not add habit. Check requirements.');
    }
  };

  const getDisabledReason = () => {
    if (habitCount >= 10) {
      return "You've reached the maximum of 10 habits this month.";
    }
    if (habitCount > 0) {
      return "Complete any habit for 3 consecutive days to unlock a new habit slot.";
    }
    return null;
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          disabled={!canAdd}
          className="gap-2"
        >
          <Plus className="w-4 h-4" />
          Add Habit
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Add New Habit</DialogTitle>
            <DialogDescription>
              Create a new habit to track. You can have up to 10 habits per month.
            </DialogDescription>
          </DialogHeader>
          <div className="py-6">
            <Label htmlFor="habit-name" className="sr-only">
              Habit name
            </Label>
            <Input
              id="habit-name"
              placeholder="e.g., Morning meditation, Read 30 minutes..."
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full"
              autoFocus
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit">Add Habit</Button>
          </DialogFooter>
        </form>
      </DialogContent>
      
      {!canAdd && (
        <p className="text-sm text-muted-foreground mt-2">
          {getDisabledReason()}
        </p>
      )}
    </Dialog>
  );
};
